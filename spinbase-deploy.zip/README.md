# SpinBase 🎡 — Deploy to Base

**SpinBase** is a fully functional spin-to-earn mini app built for **Base**.  
It includes real wallet connection, on-chain claiming simulation, multipliers, daily rewards, sounds, and PWA support.

---

## 🚀 Quick Deploy (Recommended — 20 seconds)

### Best Option: Netlify Drop (Easiest)

1. Go to → [https://netlify.com/drop](https://netlify.com/drop)
2. Drag the **entire `artifacts` folder** (or all 5 files) into the box
3. Your app is live instantly at a URL like `https://spinbase-abc123.netlify.app`

### Alternative: Vercel (Also very easy)

1. Go to → [https://vercel.com/new](https://vercel.com/new)
2. Drag the `artifacts` folder or click "Browse" and select it
3. Deploy → Done

**Main file:** `index.html` (opens automatically)

---

### After Deployment (Important!)

1. Copy your new live URL (e.g. `https://spinbase-abc123.vercel.app`)
2. Open `index.html` (or `spinbase.html`)
3. Search for `YOUR-APP-NAME.vercel.app`
4. Replace it with your real URL (there are 4 places)
5. Re-upload the file (or redeploy)

Now your app has beautiful Farcaster Frame previews!

---

## 📱 How to Get It Inside the Base App

Base supports **Mini Apps** similar to Telegram. Here's how to make SpinBase appear in Base:

### Step 1: Deploy Publicly (above)
Get a clean public URL like `https://spinbase.vercel.app`

### Step 2: Farcaster Frame Tags (Already Added!)

The HTML already includes full **Farcaster Frame vNext** + Open Graph tags for beautiful previews in Warpcast and the Base app.

**After deployment, you only need to do ONE thing:**

1. Open `spinbase.html`
2. Search for `https://your-live-url.com` (there are 4 occurrences)
3. Replace **all** of them with your actual deployed URL (e.g. `https://spinbase.vercel.app`)

That’s it — your app will now show a rich preview card when shared on Farcaster/Warpcast with a big “🎡 Spin Now on Base” button that opens the full app.

### Step 3: Share in Base Communities

- Post the link in **Base Discord**, **Farcaster**, or **Warpcast**
- Use the hashtag `#BaseMiniApp`
- Tag @base and @farcaster

Many Base mini apps get discovered this way and appear in the in-app browser.

---

## 🔧 Customization Tips

- **Change the coin name** → Search for `SPIN` in the HTML and replace
- **Add your real contract** → Update the `contractAddr` variable in the JS
- **Custom domain** → Point your ENS `.base.eth` or normal domain to the Vercel/Netlify URL

---

## 📦 Files Included

- `spinbase.html` — The complete mini app (PWA ready)
- `vercel.json` — Vercel deployment config
- `netlify.toml` — Netlify deployment config
- `README.md` — This file

---

## ❓ Need Help?

Reply with:
- "Deploy for me" (if you want me to guide you further)
- Or paste any error you get during deployment

**Your SpinBase is ready to go live on Base in under 1 minute!** 🎉

Spin. Earn. Boost. Repeat. — on Base.